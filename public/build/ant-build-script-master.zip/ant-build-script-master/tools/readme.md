# The tools that make this possible

Here's a list of the amazing tools that make this script possible

##HTML Validator

https://github.com/madr/HTMLvalidator

##JSDoc3

https://github.com/jsdoc3/jsdoc

##CSSLint

https://github.com/stubbornella/csslint

##Closure Compiler

https://developers.google.com/closure/compiler/

##JSHint

http://www.jshint.com/

##JSLint

http://www.jslint.com/

##SASS

http://sass-lang.com/

##HTMLCompressor

http://code.google.com/p/htmlcompressor/

##LESS

http://lesscss.org/

##Rhino

https://developer.mozilla.org/en-US/docs/Rhino
